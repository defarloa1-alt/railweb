# SysML Run: railweb-20250918-ops01

This run contains a minimal SysML v2 slice generated from intake requirements.

Elements:
- elem-req-railweb-scale-conversion — Scale conversion requirement
- elem-block-planning-engine — Planning Engine block
- svc-converter — Converter Service
- svc-spec-store — Spec Store

Traceability:
See `traceability.csv` for mapping from requirements to model elements.

Exports:
- Mermaid graph: `exports/mermaid.md`
- Neo4j Cypher: `exports/neo4j.cypher`
- Cytoscape CSVs: `exports/cytoscape_nodes.csv`, `exports/cytoscape_edges.csv`
