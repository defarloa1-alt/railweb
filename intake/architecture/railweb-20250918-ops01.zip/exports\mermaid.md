```mermaid
graph TD
  elem-req-railweb-scale-conversion -->|realized-by| svc-converter
  elem-req-railweb-scale-conversion -->|depends-on| svc-spec-store
  elem-block-planning-engine -->|uses| svc-converter
```
